// require express to make node server
const express = require("express");
// call express function to make server object
let app = express();
// require the connectDB function from app.js
const connectDB = require("./connect.js");
// require package layout options in HTML rendering
var expressLayouts = require("express-ejs-layouts");
// publicly accessible assets placed in the public folder are exposed
app.use(express.static("public"));

// add a middleware to parse body data for form submission
app.use(express.urlencoded({ extended: true })); // Added the extended option for parsing

// setup view engine. ejs must be installed
app.set("view engine", "ejs");
app.use(expressLayouts);

// add as many routers as you want
// idea is to have separate files for similar routes
let productsRouter = require("./routes/admin/products.router");
app.use(productsRouter);
let categoryRouter = require("./routes/admin/category.router");
const Category = require("./models/category.model");
app.use(categoryRouter);

// add as many routes as you want like below
// each route is distinguished according to two parameters 1. URL 2. HTTP method
app.get("/", async (req, res) => {
  let ProductModel = require("./models/product.model");
  let products = await ProductModel.find().populate("category");
  res.render("home", { products });
});

// Connect to MongoDB Atlas
connectDB()
  .then(() => {
    console.log("Connected to MongoDB Atlas successfully!");
    // Start the server only after the database connection is established
    app.listen(3000, () => {
      console.log("Server started at http://localhost:3000");
    });    
  })
  .catch((err) => {
    console.error("Database connection error:", err.message);
    process.exit(1); // Exit the application if the database connection fails
  });
